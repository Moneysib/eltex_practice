#!/bin/bash
cd $(dirname $(readlink -f $0))
PROCS=$(cat /proc/[0-9]*/cmdline 2>/dev/null | tr '\0' '\n')

for script in $(cat observer.conf); do
	if ! echo "$PROCS" | grep -qx "$script"; then
		nohup $script > /dev/null 2>&1 &
		echo "$(date '+%F %T') Перезапущен: $script" >> observer.log
	fi
done

