#!/bin/bash
PIPE=/run/cuckoo.pipe
NAME=$(basename $0)

if [ $NAME = temlate_task.sh ]; then
	echo "я бригадир, сам не работаю"
	exit
fi

LOG=report_$NAME.log
echo "$(date '+%F %T') [$$] Скрипт запущен" >> $LOG

mkfifo $PIPE.$$
echo "$(cat /ptoc/$$/comm) [$$]: how much time do i have?" > $PIPE
read N < $PIPE.$$
rm $PIPE.$$

sleep $N
echo "$(date '+%F %T') [$$] Скрипт завершился, работал $N секунд." >> $LOG
