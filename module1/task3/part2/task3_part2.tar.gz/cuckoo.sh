#!/bin/bash

PIPE=${1#--pishitesuda=}
LOG=$(dirname $(readlink -f $0))/cuckoo.log

trap 'echo "$(date "+%F %T") Shutdown!" >> $LOG; rm -f $PIPE; exit' TERM

mkfifo $PIPE
echo "$(date '+%F %T') Startup!" >> $LOG

while true; do
	read request < $PIPE
	name=$(echo "$request" | awk -F'[][]' '{print $1}')
	pid=$(echo "$request" | awk -F'[][]' '{print $2}')
	n=$((RANDOM % 9 + 2))
	echo $n > $PIPE.$pid
	echo "$(date '+%F %T') $name[$pid] $n" >> $LOG
done
